>Test project instruction:

1. git clone https://github.com/Artmac100/Artmac100.github.io.git
2. npm i 
3. npm i -g gulp@3.9.1
4. gulp
5. to make production version "gulp build"