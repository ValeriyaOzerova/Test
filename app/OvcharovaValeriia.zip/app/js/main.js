$(document).ready(function() {

	$('.mobile-menu').click(function(e){ 
		e.preventDefault();
	  	$('.header__topmenu').slideToggle();
	})
	$(window).resize(function() {
		var wid = $(window).width();
		if(wid > 768) {
			$('.header__topmenu').removeAttr('style');
		}
	});




});

var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("foto");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    slides[slideIndex-1].style.display = "block";  
    setTimeout(showSlides, 2000);
}

